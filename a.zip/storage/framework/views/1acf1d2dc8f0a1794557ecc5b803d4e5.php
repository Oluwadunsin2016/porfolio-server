<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test mail</title>
</head>
<body>
    <h1><?php echo e($mailData['title']); ?></h1>
    <p><?php echo e($mailData['body']); ?></p>


    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam nulla officiis, distinctio, blanditiis maxime sequi quam consequatur dolore impedit temporibus ipsa porro inventore veritatis incidunt iure libero cum dignissimos obcaecati.</p>

    <p>Thank You</p>
</body>
</html><?php /**PATH C:\Users\oluwa\Desktop\Programming\Level 5\my_portfolio\server_2\resources\views/email/contactMail.blade.php ENDPATH**/ ?>